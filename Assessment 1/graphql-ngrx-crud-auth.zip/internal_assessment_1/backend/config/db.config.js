module.exports = {
    localUrl: "mongodb://localhost:27017",
    url: "mongodb+srv://admin:T6TGuTj67F3kzeTD@test.btkcimo.mongodb.net/test",
};
