module.exports = {
    jwtKey: "jwt-access-key",
    refreshKey: "jwt-refresh-key",
    tokenValidity: "20m",
};
